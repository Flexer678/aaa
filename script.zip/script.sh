#!/bin/bash

# Extract usernames meeting the criteria
usernames=$(getent passwd | grep -E '/(home|var/spool/mail)/' | awk -F: '$3 >= 1000 {print $1}')

# Loop through the extracted usernames
for username in $usernames
do
    # Echo the username being processed
    echo "Processing user: $username"

    # Apply the chage commands to each user
    sudo chage -M 90 "$username"   # Maximum password age (in days)
    sudo chage -m 10 "$username"   # Minimum password age (in days)
    sudo chage -W 7 "$username"    # Password warning period (in days)
    sudo chage -I 30 "$username"   # Account inactive (in days)
done

# Define the SSH configuration file
ssh_config="/etc/ssh/sshd_config"

# Backup the original SSH configuration file
cp "$ssh_config" "$ssh_config.bak"

# Disable SSH root login by editing the configuration file
sed -i 's/^PermitRootLogin yes/PermitRootLogin no/' "$ssh_config"

# Restart the SSH service to apply changes
systemctl restart ssh

echo "SSH root login has been disabled."

#Stop Nginx Service
sudo systemctl stop nginx

#Gets new application updates and updates package index files
sudo apt-get update
sudo apt upgrade

#Enable Automatic System Updates
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
sudo systemctl enable unattended-upgrades
sudo systemctl start unattended-upgrades

#Install Fail2ban
sudo apt install fail2ban

# Enable UFW
sudo ufw enable

# Allow SSH (if you're connecting remotely)
sudo ufw allow OpenSSH

# Allow necessary services and ports (e.g., HTTP, HTTPS)
# Replace 'port_number' with the actual port numbers you need
sudo ufw allow port_number/tcp

# Enable UFW logging (optional)
sudo ufw logging on

# Check UFW status
sudo ufw status

#Disable FTP service
sudo systemctl stop pure-ftpd

#Install Auditd and update packages
sudo apt update
sudo apt install auditd
auditctl –e 1

#Install Netcad
sudo apt install netcat

#Install Gufw
sudo apt install gufw

#Install Bum
sudo apt install bum

#Install RKHunter 
sudo apt install wget
sudo apt-get -y install rkhunter
sudo rkhunter --propupd

#Asks if you would like RKHunter to run
read -p "Would you like RKHunter to run a check for rootkits and suspicious files? (y/n)": inp
if [[ $inp == "y" ]]; then
  echo -ne '\n'| sudo rkhunter --check
elif [[ $inp == "n" ]]; then 
  echo "RKHunter not running a check"
else
  echo "You entered an unknown value. Please enter 'y' or 'n'."
fi

while true; do
  read -p "Would you like to uninstall common hacking tools? (y/n):" inp
  if [[ $inp == "y" ]]; then
    # Remove Hacking Tools
    # Declare an empty array
    program_array=()

    # Check if "programs.txt" exists
    if [ -f "programs.txt" ]; then
      # Read the program names from the file into the array
      while IFS= read -r program_name; do
        program_array+=("$program_name")
      done < "programs.txt"

      # Uninstall programs based on the array
      for program in "${program_array[@]}"; do
        echo "Uninstalling $program..."
        sudo apt remove -y "$program"  
      done
    else
      echo "The 'programs.txt' file does not exist."
    fi
    break  # Exit the loop after successful uninstallation
  elif [[ $inp == "n" ]]; then
    echo "Common Hacking Tools not uninstalled"
    break  # Exit the loop if the user selects "n"
  else
    echo "You entered an unknown value. Please enter 'y' or 'n'."
  fi
done

while true; do
  read -p "Would you like to see media files that end in a .png, .jpeg, .mp4, .mp3? (y/n):" inp
  if [[ $inp == "y" ]]; then
    locate *.png
    locate *.jpeg
    locate *.mp4
    locate *.mp3
    break  # Exit the loop after search
  elif [[ $inp == "n" ]]; then
    echo "Not searching for Media Files"
    break  # Exit the loop denying
  else
    echo "You entered an unknown value. Please enter 'y' or 'n'."
  fi
done

while true; do
  read -p "Would you like to see media files that end in a .png, .jpeg, .mp4, .mp3? (y/n):" inp
  if [[ $inp == "y" ]]; then
    # Sorts Administrators/Users
    # Initialize arrays for administrators and regular users
    admins=()
    regular_users=()

    # Loop through the extracted usernames
    for username in $usernames
    do
      # Check if the user is a member of the sudo group (admin)
      if groups "$username" | grep -q '\bsudo\b'; then
          admins+=("$username")
      else
          regular_users+=("$username")
      fi
    done
  elif [[ $inp == "n" ]]; then
    echo "Not sorting through Administrators and Users"
    break  # Exit the loop if the user selects "n"
  else
    echo "You entered an unknown value. Please enter 'y' or 'n'."
  fi
done